<?php

if ($_POST['g-recaptcha-response'] == '') {

} else {
$obj = new stdClass();
$obj->secret = "6LegSHMiAAAAAKmN9muGjjeNKNU_XY9bs1_b257j";
$obj->response = $_POST['g-recaptcha-response'];
$obj->remoteip = $_SERVER['REMOTE_ADDR'];
$url = 'https://www.google.com/recaptcha/api/siteverify';

$options = array(
'http' => array(
'header' => "Content-type: application/x-www-form-urlencoded\r\n",
'method' => 'POST',
'content' => http_build_query($obj)
)
);
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

$validar = json_decode($result);

/*  FIN DE CAPTCHA   */

if ($validar->success) {
$email = trim($_POST['email']);
$name = trim($_POST['name']);
$date = trim($_POST['date']);
$service = trim($_POST['service']);
$phone = trim($_POST['phone']);
$message = trim($_POST['message']);

$consulta =  "Nombre:: " . $name . "\n Correo: " . $email . "\n Requiere información de " . $service  .  "\n Numero de contacto: " . $number  .  "\n Para la fecha de:  . $date  .  "\n Mensaje: " . $message;
echo '
            <script>
                 alert("Gracias por comunicarte");
                 
            </script>        
        ';

mail("echong.pbxhosting@gmail.com", "Formulario - Nuevo Paciente", $consulta);header("location:index.html");
} 

else {
    echo '
    <script>
         alert("Error resuelva el captcha");
         window.location = "https://casv3.com/";
    </script>        
';
header("location:index.html");

}
}
?>